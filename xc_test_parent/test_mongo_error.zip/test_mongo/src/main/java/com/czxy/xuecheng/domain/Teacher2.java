package com.czxy.xuecheng.domain;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Created by liangtong.
 */
@Data
//@Document(collection = "teacher2")
public class Teacher2 {
    @Id
    private String id;
    private String username;
    private String marry;
    private String password;
    //private Integer age;
}
