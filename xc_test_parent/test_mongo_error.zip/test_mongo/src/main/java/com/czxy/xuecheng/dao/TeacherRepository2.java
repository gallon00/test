package com.czxy.xuecheng.dao;

import com.czxy.xuecheng.domain.Teacher2;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

/**
 * Created by liangtong.
 */
public interface TeacherRepository2 extends MongoRepository<Teacher2,String> {
    //根据名称查询
    public Teacher2 findByName(String name);

    //根据名称模糊查询
    public List<Teacher2> findByNameLike(String name);

    //根据名称和年龄查询
    public List<Teacher2> findByNameLikeAndAge(String name, Integer age);

    //根据名称和年龄，分页查询
    public Page<Teacher2> findByNameLikeAndAge(String name, Integer age, Pageable pageable);
}
