package com.czxy.xuecheng;

import com.mongodb.client.gridfs.model.GridFSFile;
import org.bson.types.ObjectId;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * Created by liangtong.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
public class TestGridFS {
//
//    @Resource
//    private GridFsTemplate gridFsTemplate;

    @Test
    public void testStore() throws FileNotFoundException {
//        //要存储的文件
//        File file = new File("F:/liangtong/index.html");
//        //定义输入流
//        FileInputStream inputStram = new FileInputStream(file);
//        //向GridFS存储文件
//        ObjectId objectId = gridFsTemplate.store(inputStram, "轮播图测试文件01", "");
//        //得到文件ID
//        System.out.println(objectId);
        System.out.println("...");
    }
}
