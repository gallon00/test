package com.czxy.xuecheng;

import com.czxy.xuecheng.dao.TeacherRepository2;
import com.czxy.xuecheng.domain.Teacher2;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Created by liangtong.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
public class TestRepository2 {
    @Resource
    private TeacherRepository2 teacherRepository;
    @Test
    public void testFindAll(){
        //查询
        List<Teacher2> list = teacherRepository.findAll();
        System.out.println(list);
    }

    @Test
    public void testInsert(){
        Teacher2 teacher = new Teacher2();
        teacher.setUsername("M老师");
        //teacher.setAge(25);
//        teacher.setMarry("女昏");
        teacherRepository.insert(teacher);
    }

    @Test
    public void testUpdate(){
        Optional<Teacher2> optional = teacherRepository.findById("5ede4bf43335a82d386f49ff");
        if(optional.isPresent()){
            Teacher2 teacher = optional.get();
            teacher.setUsername("CC老师");
            teacherRepository.save(teacher);
        }
    }

    @Test
    public void testDelete(){
        teacherRepository.deleteById("5ede57fd3335a8258875e0f2");
    }

    @Test
    public void testPage(){
        int page = 0; //从0开始
        int size = 2;//每页记录数
        PageRequest pageRequest = PageRequest.of(page, size);
        //查询
        Page<Teacher2> all = teacherRepository.findAll(pageRequest);
        // 总条数
        System.out.println(all.getTotalElements());
        // 当前页信息
        all.forEach(teacher -> {
            System.out.println(teacher);
        });
        // 将stream转换成List
        List<Teacher2> list = all.get().collect(Collectors.toList());
        System.out.println(list);
    }

    @Test
    public void testDao(){
//        Teacher2 teacher = teacherRepository.findByName("CC老师");
//        System.out.println(teacher);
//
//        List<Teacher2> list = teacherRepository.findByNameLike("老师");
//        System.out.println(list);
//
//        List<Teacher2> list2 = teacherRepository.findByNameLikeAndAge("老师", 18);
//        System.out.println(list2);
//
//        PageRequest pageRequest = PageRequest.of(0, 1);
//        Page<Teacher2> page = teacherRepository.findByNameLikeAndAge("老师", 18, pageRequest);
//        List<Teacher2> list3 = page.get().collect(Collectors.toList());
//        System.out.println(list3);

    }

    @Test
    public void testExample(){

        int page = 0; //从0开始
        int size = 2;//每页记录数
        PageRequest pageRequest = PageRequest.of(page, size);


        //查询条件
        Teacher2 teacher = new Teacher2();
        teacher.setUsername("");
        // 1 条件匹配器
        ExampleMatcher matcher = ExampleMatcher.matching()
                .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING)  //默认字符串匹配方式：模糊查询
                .withIgnoreCase(true)   //默认大小写忽略方式：忽略大小写
                .withMatcher("username",ExampleMatcher.GenericPropertyMatchers.contains())  //采用“包含匹配”的方式查询
                .withIgnorePaths("pageNum","pageSize");  //忽略属性，不参与查询
        // 2 条件对象
        Example<Teacher2> example = Example.of( teacher , matcher);


        //查询
        Page<Teacher2> all = teacherRepository.findAll(example , pageRequest);

        // 将stream转换成List
        List<Teacher2> list = all.get().collect(Collectors.toList());
        System.out.println(list);
    }

}
